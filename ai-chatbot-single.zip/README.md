# AI Chatbot - Single File Node.js Project

## Overview
A simple AI chatbot with both backend (Express) and frontend (HTML/CSS/JS) in one project folder.

## Installation & Usage
1. Install dependencies:
   ```bash
   npm install
   ```
2. Start server:
   ```bash
   npm start
   ```
3. Open browser at `http://localhost:4000`

## API
- POST `/api/chat` - send `{ "message": "..." }`, returns `{ "reply": "..." }`.

## Notes
- Currently, the bot just echoes messages. Replace logic in `/api/chat` with real AI calls.
- Use `.env` to store secrets.
